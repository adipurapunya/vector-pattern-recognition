/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import static coba.ReadTemps.getData;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author adipura
 */

public class LVQ
{
    private static final int NUMBER_OF_CLUSTERS = 4;
    private static final int VEC_LEN = 640;
    private static final int TRAINING_PATTERNS = 12;
    
    private static final double DECAY_RATE = 0.96; // About 100 iterations. 
    private static final double MIN_ALPHA = 0.01;

    private static double alpha = 0.6;
    private static double d[] = null; // Network nodes. The "clusters"
    
    private static double bobot_akhir = 0;
    //
    private static double[] bobotakhirA1;
    private static double[] bobotakhirB1;
    private static double[] bobotakhirC1;
    private static double[] bobotakhirD1;
    private static double[] bobotakhirE1;
    private static double[] bobotakhirJ1;
    private static double[] bobotakhirK1;
    
    private static double[] bobotakhirA2;
    private static double[] bobotakhirB2;
    private static double[] bobotakhirC2;
    private static double[] bobotakhirD2;
    private static double[] bobotakhirE2;
    private static double[] bobotakhirJ2;
    private static double[] bobotakhirK2;
    
    private static double[] bobotakhirA3;
    private static double[] bobotakhirB3;
    private static double[] bobotakhirC3;
    private static double[] bobotakhirD3;
    private static double[] bobotakhirE3;
    private static double[] bobotakhirJ3;
    private static double[] bobotakhirK3;
    
    
//Weight matrix.
    private static double w[][] = null;

    //Training patterns.
    private static int mPattern[][] = null;
    private static int mTarget[] = null;
    
    public static void initialize()
    {
        //Insert pattern arrays into mPattern() to make an array of arrays.
        mPattern = new int[TRAINING_PATTERNS][];
        mPattern[0] = A1;
        mPattern[1] = B1;
        mPattern[2] = C1;
        mPattern[3] = D1;
        //mPattern[4] = E1;
        //mPattern[5] = J1;
        //mPattern[6] = K1;
        
        mPattern[4] = A2;
        mPattern[5] = B2;
        mPattern[6] = C2;
        mPattern[7] = D2;
        //mPattern[11] = E2;
        //mPattern[12] = J2;
        //mPattern[13] = K2;
        
        mPattern[8] = A3;
        mPattern[9] = B3;
        mPattern[10] = C3;
        mPattern[11] = D3;
        //mPattern[18] = E3;
        //mPattern[19] = J3;
        //mPattern[20] = K3;
        
        //mPattern[21] = X1;
        
        d = new double[NUMBER_OF_CLUSTERS]; // Network nodes.
        
        //mTarget = new int[] {0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6};
        mTarget = new int[] {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3};
        // Weight matrix to be filled with values between 0.0 and 1.0
        w = new double[NUMBER_OF_CLUSTERS][VEC_LEN];
        return;
    }
    
    public static void initializeWeights(int clusterNumber, int trainingPattern[])
    {
        // clusterNumber = the output node (cluster) to assign the pattern to.
        // trainingPattern = the pattern which the output node will respond to.
        // Initialize weights.
        for(int i = 0; i < VEC_LEN; i++)
        {
            w[clusterNumber][i] = trainingPattern[i];
            //System.out.println("Bobot "+"["+i+"]"+w[clusterNumber][i]);
        }
    }
    
    private static void training()
    {
        int dMin = 0, count = 0;
        
        while(alpha > MIN_ALPHA)
        {
            //System.out.println("Count "+count);
            for(int VecNum = 0; VecNum < TRAINING_PATTERNS; VecNum++)
            {
                // Compute input for all nodes.
                computeInput(mPattern, VecNum);
                // See which is smaller?
                dMin = minimum(d);
                // Update the weights on the winning unit.
                String x = updateWeights(VecNum, dMin);
                if(count==100)
                {
                    System.out.println("Bobot["+VecNum+"] :");
                    System.out.println(x);
                    if(VecNum==0)
                    {
                        bobotakhirA1 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==1)
                    {
                        bobotakhirB1 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==2)
                    {
                        bobotakhirC1 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==3)
                    {
                        bobotakhirD1 = getVektorBobotAkhir(x);
                    }
                    /*
                    else if(VecNum==4)
                    {
                        bobotakhirE1 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==5)
                    {
                        bobotakhirJ1 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==6)
                    {
                        bobotakhirK1 = getVektorBobotAkhir(x);
                    }
                    */
                    else if(VecNum==4)
                    {
                        bobotakhirA2 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==5)
                    {
                        bobotakhirB2 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==6)
                    {
                        bobotakhirC2 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==7)
                    {
                        bobotakhirD2 = getVektorBobotAkhir(x);
                    }
                    /*
                    else if(VecNum==11)
                    {
                        bobotakhirE2 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==12)
                    {
                        bobotakhirJ2 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==13)
                    {
                        bobotakhirK2 = getVektorBobotAkhir(x);
                    }
                    */
                    else if(VecNum==8)
                    {
                        bobotakhirA3 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==9)
                    {
                        bobotakhirB3 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==10)
                    {
                        bobotakhirC3 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==11)
                    {
                        bobotakhirD3 = getVektorBobotAkhir(x);
                    }
                    
                    /*
                    else if(VecNum==18)
                    {
                        bobotakhirE3 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==19)
                    {
                        bobotakhirJ3 = getVektorBobotAkhir(x);
                    }
                    else if(VecNum==20)
                    {
                        bobotakhirK3 = getVektorBobotAkhir(x);
                    }
                    */
                }
            } // VecNum
            // Reduce the learning rate.
            alpha = DECAY_RATE * alpha;
            count++;
        }
    }
    
    public static int getCluster(int[] inputPattern)
    {
        // Compute input for all nodes.
        computeInput(inputPattern);
        // See which is smaller?
        return minimum(d);
    }
    
    private static String updateWeights(int vectorNumber, int dMin)
    {
        String dd = "";
        for(int i = 0; i < VEC_LEN; i++)
        {
            // Update the winner.
            
            if(dMin == mTarget[vectorNumber])
            {
                w[dMin][i] += (alpha * (mPattern[vectorNumber][i] - w[dMin][i]));
                //System.out.println("Bobot sama "+w[dMin][i]);
                bobot_akhir = w[dMin][i];
                dd = dd +bobot_akhir+"\n";
            }
            else
            {
                w[dMin][i] -= (alpha * (mPattern[vectorNumber][i] - w[dMin][i]));
                //System.out.println("Bobot beda "+w[dMin][i]);
                bobot_akhir = w[dMin][i];
                dd = dd +bobot_akhir+"\n";
            }
        }
        //System.out.println("Bobot akhir : "+bobot_akhir);
        return dd;
    }
    
    private static void computeInput(int[][] vectorArray, int vectorNumber)
    {
        // Overloaded function.  See computeInput below.
        clearArray(d);
        for(int i = 0; i < NUMBER_OF_CLUSTERS; i++)
        {
            for(int j = 0; j < VEC_LEN; j++)
            {
                d[i] += Math.pow((w[i][j] - vectorArray[vectorNumber][j]), 2);
            } // j
        } // i
        return;
    }
    
    private static void computeInput(int[] vectorArray)
    {
        // Overloaded function.  See computeInput above.
        clearArray(d);
        for(int i = 0; i < NUMBER_OF_CLUSTERS; i++)
        {
            for(int j = 0; j < VEC_LEN; j++)
            {
                d[i] += Math.pow((w[i][j] - vectorArray[j]), 2);
            } // j
        } // i
        return;
    }
    
    private static void clearArray(double[] anArray)
    {
        for(int i = 0; i < NUMBER_OF_CLUSTERS; i++)
        {
            anArray[i] = 0.0;
        }
        return;
    }
    
    private static int minimum(double[] nodeArray)
    {
        int winner = 0;
        boolean foundNewWinner = false;
        boolean done = false;

        while(!done)
        {
            foundNewWinner = false;
            for(int i = 0; i < NUMBER_OF_CLUSTERS; i++)
            {
                if(i != winner)
                {             //Avoid self-comparison.
                    if(nodeArray[i] < nodeArray[winner]){
                        winner = i;
                        foundNewWinner = true;
                    }
                }
            }

            if(foundNewWinner == false){
                done = true;
            }

        }
        return winner;
    }
    private static int[] A1 = getData("data/A1.txt");
    private static int[] B1 = getData("data/B1.txt");
    private static int[] C1 = getData("data/C1.txt");
    private static int[] D1 = getData("data/D1.txt");
    //private static int[] E1 = getData("data/E1.txt");
    //private static int[] J1 = getData("data/J1.txt");
    //private static int[] K1 = getData("data/K1.txt");
    
    private static int[] A2 = getData("data/A2.txt");
    private static int[] B2 = getData("data/B2.txt");
    private static int[] C2 = getData("data/C2.txt");
    private static int[] D2 = getData("data/D2.txt");
    //private static int[] E2 = getData("data/E2.txt");
    //private static int[] J2 = getData("data/J2.txt");
    //private static int[] K2 = getData("data/K2.txt");
    
    private static int[] A3 = getData("data/A3.txt");
    private static int[] B3 = getData("data/B3.txt");
    private static int[] C3 = getData("data/C3.txt");
    private static int[] D3 = getData("data/D3.txt");
    //private static int[] E3 = getData("data/E3.txt");
    //private static int[] J3 = getData("data/J3.txt");
    //private static int[] K3 = getData("data/K3.txt");
    
    private static int[] sampel1 = getData("data/sampel1.txt");
    private static int[] sampel2 = getData("data/sampel2.txt");
    
    private static double[] getVektorBobotAkhir(String vektor)
    {
        double[] dataArray = new double [640];
        String[] data = vektor.split("\n");
        int i=0;
        for(String x : data)
        {
            dataArray[i] = Double.parseDouble(x);
            i++;
        }
        return dataArray;
    }
   
    
    private static int[] getData(String fileName)
    {
        int[] data = new int [640];
        BufferedReader in = null;
        try 
        {
            in = new BufferedReader(new FileReader(fileName));
            String str;    
            int i=0;
            while((str = in.readLine()) != null)
            {
                data[i]= Integer.parseInt(str);
                i++;
            }
        } 
        catch (Exception e)
        {
               System.out.println(e.getMessage());
        }
        finally
        {
            try {
                in.close();
            } catch (Exception e) {
            }
        }
        return data;
        
    }
    
    private static String[] mFontNames = new String[] {"A1", "B1", "C1", "D1",  
                                                       "A2", "B2", "C2", "D2",
                                                       "A3", "B3", "C3", "D3"};
    
    /*private static String[] mFontNames = new String[] {"A1", "B1", "C1", "D1", "E1", "J1", "K1", 
                                                       "A2", "B2", "C2", "D2", "E2", "J2", "K2", 
                                                       "A3", "B3", "C3", "D3", "E3", "J3", "K3"};*/
    
    private static double ComputeEuclideanDistance(int[] vector1, double[] vector2)
    {
		double result;
		double distance =0;
		for(int j=0;j<640;j++)
                {
			distance += Math.pow((vector1[j] - vector2[j]), 2);
		}
		result = distance;
		return result;
    }
     
    public void doTrain()
    {
        initialize();

        for(int i = 0; i < NUMBER_OF_CLUSTERS; i++)
        {
            initializeWeights(i, mPattern[i]);
            //System.out.println("Batas "+i);
            //System.out.println("Weights for cluster " + i + " initialized to pattern " + mFontNames[i]);
            
        }
        
        training();
        
        // Display results
        String data = "";
        for(int i = 0; i < TRAINING_PATTERNS; i++)
        {
            //System.out.println("Pattern " + mFontNames[i] + " belongs to cluster " + getCluster(mPattern[i]));
            data = data +"Pola " + mFontNames[i] + " masuk kluster : " + getCluster(mPattern[i])+"\n";
        }
        GrayscaleApp.txtListHasilLatih.setText(data);
    }
    
    public void getBobotAkhir()
    {
        String A1="";
        for(int i=0;i<bobotakhirA1.length;i++)
        {
            A1 = A1 + String.valueOf(bobotakhirA1[i])+" , ";
        }
        
        String B1="";
        for(int i=0;i<bobotakhirB1.length;i++)
        {
            B1 = B1 + String.valueOf(bobotakhirB1[i])+" , ";
        }
        
        String C1="";
        for(int i=0;i<bobotakhirC1.length;i++)
        {
            C1 = C1 + String.valueOf(bobotakhirC1[i])+" , ";
        }
        
        String D1="";
        for(int i=0;i<bobotakhirD1.length;i++)
        {
            D1 = D1 + String.valueOf(bobotakhirD1[i])+" , ";
        }
        
        
        
        
        String A2="";
        for(int i=0;i<bobotakhirA1.length;i++)
        {
            A2 = A2 + String.valueOf(bobotakhirA2[i])+" , ";
        }
        
        String B2="";
        for(int i=0;i<bobotakhirB1.length;i++)
        {
            B2 = B2 + String.valueOf(bobotakhirB2[i])+" , ";
        }
        
        String C2="";
        for(int i=0;i<bobotakhirC1.length;i++)
        {
            C2 = C2 + String.valueOf(bobotakhirC2[i])+" , ";
        }
        
        String D2="";
        for(int i=0;i<bobotakhirD1.length;i++)
        {
            D2 = D2 + String.valueOf(bobotakhirD2[i])+" , ";
        }
        
        
        String A3="";
        for(int i=0;i<bobotakhirA3.length;i++)
        {
            A3 = A3 + String.valueOf(bobotakhirA3[i])+" , ";
        }
        
        String B3="";
        for(int i=0;i<bobotakhirB3.length;i++)
        {
            B3 = B3 + String.valueOf(bobotakhirB3[i])+" , ";
        }
        
        String C3="";
        for(int i=0;i<bobotakhirC3.length;i++)
        {
            C3 = C3 + String.valueOf(bobotakhirC3[i])+" , ";
        }
        
        String D3="";
        for(int i=0;i<bobotakhirD3.length;i++)
        {
            D3 = D3 + String.valueOf(bobotakhirD3[i])+" , ";
        }
        
       GrayscaleApp.txtListBobotAkhir.setText(A1+"\n"+B1+"\n"+C1+"\n"+D1+"\n"+A2+"\n"+B2+"\n"+C2+"\n"+D2+"\n"+A3+"\n"+B3+"\n"+C3+"\n"+D3+"\n");
    }
    
    public static void cekhasil(String nama)
    {
        String data = "";
        String namaVektorInput = nama;
        //System.out.println("dddd "+namaVektorInput);
        if(namaVektorInput.equals("sampel1"))
        {
            data = data + ComputeEuclideanDistance(sampel1,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(sampel1,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(sampel1,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(sampel1,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(sampel1,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(sampel1,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(sampel1,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(sampel1,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(sampel1,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(sampel1,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(sampel1,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(sampel1,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        else if(namaVektorInput.equals("sampel2"))
        {
            data = data + ComputeEuclideanDistance(sampel2,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(sampel2,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(sampel2,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(sampel2,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(sampel2,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(sampel2,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(sampel2,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(sampel2,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(sampel2,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(sampel2,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(sampel2,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(sampel2,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("A1"))
        {
            data = data + ComputeEuclideanDistance(A1,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(A1,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(A1,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(A1,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(A1,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(A1,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(A1,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(A1,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(A1,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(A1,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(A1,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(A1,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("A2"))
        {
            data = data + ComputeEuclideanDistance(A2,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(A2,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(A2,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(A2,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(A2,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(A2,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(A2,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(A2,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(A2,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(A2,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(A2,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(A2,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("A3"))
        {
            data = data + ComputeEuclideanDistance(A3,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(A3,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(A3,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(A3,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(A3,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(A3,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(A3,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(A3,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(A3,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(A3,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(A3,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(A3,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("B1"))
        {
            data = data + ComputeEuclideanDistance(B1,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(B1,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(B1,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(B1,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(B1,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(B1,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(B1,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(B1,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(B1,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(B1,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(B1,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(B1,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("B2"))
        {
            data = data + ComputeEuclideanDistance(B2,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(B2,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(B2,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(B2,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(B2,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(B2,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(B2,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(B2,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(B2,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(B2,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(B2,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(B2,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("B3"))
        {
            data = data + ComputeEuclideanDistance(B3,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(B3,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(B3,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(B3,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(B3,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(B3,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(B3,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(B3,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(B3,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(B3,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(B3,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(B3,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("C1"))
        {
            data = data + ComputeEuclideanDistance(C1,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(C1,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(C1,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(C1,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(C1,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(C1,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(C1,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(C1,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(C1,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(C1,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(C1,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(C1,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("C2"))
        {
            data = data + ComputeEuclideanDistance(C2,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(C2,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(C2,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(C2,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(C2,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(C2,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(C2,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(C2,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(C2,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(C2,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(C2,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(C2,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("C3"))
        {
            data = data + ComputeEuclideanDistance(C3,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(C3,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(C3,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(C3,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(C3,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(C3,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(C3,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(C3,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(C3,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(C3,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(C3,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(C3,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("D1"))
        {
            data = data + ComputeEuclideanDistance(D1,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(D1,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(D1,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(D1,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(D1,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(D1,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(D1,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(D1,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(D1,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(D1,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(D1,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(D1,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("D2"))
        {
            data = data + ComputeEuclideanDistance(D2,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(D2,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(D2,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(D2,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(D2,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(D2,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(D2,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(D2,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(D2,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(D2,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(D2,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(D2,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
        else if(namaVektorInput.equals("D3"))
        {
            data = data + ComputeEuclideanDistance(D3,bobotakhirA1)+" => Jarak ke Pola A1 \n"
                    + ComputeEuclideanDistance(D3,bobotakhirB1)+" => Jarak ke Pola B1 \n"
                    + ComputeEuclideanDistance(D3,bobotakhirC1)+" => Jarak ke Pola C1 \n"
                    + ComputeEuclideanDistance(D3,bobotakhirD1)+" => Jarak ke Pola D1 \n\n"
                
                    + ComputeEuclideanDistance(D3,bobotakhirA2)+" => Jarak ke Pola A2 \n"
                    + ComputeEuclideanDistance(D3,bobotakhirB2)+" => Jarak ke Pola B2 \n"
                    + ComputeEuclideanDistance(D3,bobotakhirC2)+" => Jarak ke Pola C2 \n"
                    + ComputeEuclideanDistance(D3,bobotakhirD2)+" => Jarak ke Pola D2 \n\n"
                    
                    + ComputeEuclideanDistance(D3,bobotakhirA3)+" => Jarak ke Pola A3 \n"
                    + ComputeEuclideanDistance(D3,bobotakhirB3)+" => Jarak ke Pola B3 \n"
                    + ComputeEuclideanDistance(D3,bobotakhirC3)+" => Jarak ke Pola C3 \n"
                    + ComputeEuclideanDistance(D3,bobotakhirD3)+" => Jarak ke Pola D3 \n";
            GrayscaleApp.jTextAreaHasilCek.setText(data);
        }
        
    }
    /*
    public static void main(String[] args)
    {
        initialize();

        for(int i = 0; i < NUMBER_OF_CLUSTERS; i++)
        {
            initializeWeights(i, mPattern[i]);
            //System.out.println("Batas "+i);
            //System.out.println("Weights for cluster " + i + " initialized to pattern " + mFontNames[i]);
        }

        training();
        
        // Display results
        for(int i = 0; i < TRAINING_PATTERNS; i++)
        {
            System.out.println("Pattern " + mFontNames[i] + " belongs to cluster " + getCluster(mPattern[i]));
        }
        /*
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirA1)+" Kelas A1");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirB1)+" Kelas B1");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirC1)+" Kelas C1");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirD1)+" Kelas D1");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirE1)+" Kelas E1");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirJ1)+" Kelas J1");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirK1)+" Kelas K1");
        System.out.println("==");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirA2)+" Kelas A2");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirB2)+" Kelas B2");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirC2)+" Kelas C2");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirD2)+" Kelas D2");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirE2)+" Kelas E2");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirJ2)+" Kelas J2");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirK2)+" Kelas K2");
        System.out.println("==");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirA3)+" Kelas A3");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirB3)+" Kelas B3");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirC3)+" Kelas B3");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirD3)+" Kelas C3");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirE3)+" Kelas D3");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirJ3)+" Kelas J3");
        System.out.println(ComputeEuclideanDistance(sampel,bobotakhirK3)+" Kelas K3");
       
        return;
    }
        */
}